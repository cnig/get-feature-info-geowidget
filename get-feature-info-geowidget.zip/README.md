get-feature-info-geowidget
==========================